#' Package RxpsG
#'
#' Processing tools for X ray Photoelectron Spectroscopy Data.
#' The package implements classes and methods to read, visualize and manipulate XPS spectra files.
#' The spectra can be obtained from .pxt and .vms data format from different instruments.
#' More generally, any data that is recorded as a list of (x,y) data is suitable.
#'
#' @import digest import latticeExtra memoise minpack.lm signal
#' @suggests rootSolve
#'
#'
#' @importFrom graphics grconvertX grconvertY arrows axTicks axis box grid
#'             layout legend lines locator matlines matplot mtext par plot.new
#'             points rect segments text
#'
#' @importFrom grDevices x11 dev.cur dev.print graphics.off bmp jpeg pdf
#'             png postscript tiff recordPlot replayPlot
#'
#' @importFrom methods as formalArgs new show slot "slot<-"
#'
#' @importFrom minpack.lm nlsLM nls.lm nls.lm.control
#'
#' @importFrom stats as.formula coef convolve fft fitted formula getInitial lm
#'             model.weights na.omit nls.control numericDeriv predict residuals
#'             setNames spline window
#'
#' @importFrom utils capture.output install.packages read.table write.csv write.csv2 write.table
#'
#' @docType package
#' @name RxpsG
NULL



#Loads the autoscroll.tcl library to manage the scrollbars added to widgets
#run the RxpsG software

.onAttach <- function(...) {
   addTclPath(system.file("tklibs", package="RxpsG", lib.loc=.libPaths()))
   tcl("source", system.file("tklibs", "autoscroll.tcl", package="RxpsG"))
   cat("\n autoscroll.tcl library loaded \n")
   xps()
}
                                                                          

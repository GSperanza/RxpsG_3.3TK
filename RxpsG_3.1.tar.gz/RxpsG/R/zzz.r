#Loads the autoscroll.tcl library to manage the scrollbars added to widgets
#run the RxpsG software

.onAttach <- function(...) {
   library('tcltk')
   addTclPath(system.file("tklibs", package="RxpsG", lib.loc=.libPaths()))
   tcl("source", system.file("tklibs", "autoscroll.tcl", package="RxpsG"))
   xps()
}

#Loads the autoscroll.tcl library to manage the scrollbars added to widgets
#run the RxpsG software

.onAttach <- function(...) {
   addTclPath(system.file("tklibs", package="RxpsG", lib.loc=.libPaths()))
   tcl("source", system.file("tklibs", "autoscroll.tcl", package="RxpsG"))

#---GlobalVar initialization 
   activeFName <- activeSpectIndx <- activeSpectName <- NULL
   XPSSettings <- Pkgs <- NULL
   grDevices <- quartz <- NULL
     
   assign("activeFName", activeFName, envir=.GlobalEnv)
   assign("activeSpectIndx", activeSpectIndx, envir=.GlobalEnv)
   assign("activeSpectName", activeSpectName, envir=.GlobalEnv)
   assign("XPSSettings", XPSSettings, envir=.GlobalEnv)
   assign("Pkgs", Pkgs, envir=.GlobalEnv)
   assign("grDevices", grDevices, envir=.GlobalEnv)  
   assign("quartz", quartz, envir=.GlobalEnv)
#---



   xps()
}
                                                                          

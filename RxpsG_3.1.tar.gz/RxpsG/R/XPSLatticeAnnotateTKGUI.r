#Function to annotate Lattice plots

#' @title XPSLattAnnotate
#' @description XPSLattAnnotate function adds text to a plot produced
#'   using the Lattice package
#'   This function is called by (\code{XPSOverlay}) and (\code{XPSCustomPlot})
#' @param Xlim the limits of the X axis
#' @param Ylim the limits of the Y axis
#' @examples
#' \dontrun{
#'  	XPSLattAnnotate(Xlim, Ylim)
#' }
#' @export
#'

XPSLattAnnotate <- function(Xlim,Ylim){

   CtrlPlot <- function(){
#               replayPlot(RecPlot)
               if (TextColor=="Color"){TextColor <<- SpectColor}

               panel.text(x=TextPosition$x,y=TextPosition$y, pos=4, labels=AnnotateText,cex=TextSize,col=TextColor)
               trellis.unfocus()
   }


#--- variables ---
   if (is.na(activeFName)){
       tkmessageBox(message="No data present: please load and XPS Sample", title="XPS SAMPLES MISSING", icon="error")
       return()
   }
   FName <- get(activeFName, envir=.GlobalEnv)
   ActiveFName <- get("activeFName", envir=.GlobalEnv)
   SpectIndx <- get("activeSpectIndx", envir=.GlobalEnv)
   SpectList <- XPSSpectList(ActiveFName)   #List of the CoreLines in FName

   Colors <- XPSSettings$Colors
   FontSize <- c(0.4,0.6,0.8,1,1.2,1.4,1.6,1.8,2,2.2,2.4,2.6,2.8,3)
   FontCol <- c("black", "red", "limegreen", "blue", "magenta", "orange", "grey", "cyan", "sienna", "cadetblue", "darkgreen", "grey45", "gold", "violet", "yellow", "lightblue", "turquoise", "pink", "wheat", "thistle")
   TextPosition <- list(x=NULL, y=NULL)
   TextSize <- 1
   TextColor <- "black"
   SpectColor <- "black"
   AnnotateText <- "?"
   RecPlot <- recordPlot()
   AcceptedPlot <- recordPlot()   #save the plot before Annotation to make UNDO
   SampData <- setAsMatrix(FName[[SpectIndx]],"matrix") #store spectrum baseline etc in a matrix


#----- Widget -----

     AnnWin <- tktoplevel()
     tkwm.title(AnnWin,"ANNOTATE")
     tkwm.geometry(AnnWin, "+100+50")   #SCREEN POSITION from top-left corner

     AnnGroup <- ttkframe(AnnWin,  borderwidth=0, padding=c(0,0,0,0))
     tkgrid(AnnGroup, row = 1, column = 1, sticky="we")

     INFOframe <- ttklabelframe(AnnGroup, text = " HELP ", borderwidth=2)
     tkgrid(INFOframe, row = 2, column = 1, padx = 5, pady = 5, sticky="we")
     tkgrid( ttklabel(INFOframe, text="1. Mouse-locate Position and Set the Label"),
             row = 1, column=1, pady=2, sticky="w")
     tkgrid( ttklabel(INFOframe, text="2. Change Size and Color if Needed"),
             row = 2, column=1, pady=2, sticky="w")
     tkgrid( ttklabel(INFOframe, text="3. ACCEPT if Label OK or UNDO to the Previous Plot "),
             row = 3, column=1, pady=2, sticky="w")

     Anframe1 <- ttklabelframe(AnnGroup, text = " Text ", borderwidth=2)
     tkgrid(Anframe1, row = 3, column = 1, padx = 5, pady = 5, sticky="we")
     tkgrid( ttklabel(Anframe1, text=" Text to Annotate: "),
             row = 1, column = 1, padx = 5, pady = 5, sticky="we")
     AnnTxt <- tclVar("Label?")
     AnnEntry1 <- ttkentry(Anframe1, textvariable=AnnTxt, foreground="grey")
     tkgrid(AnnEntry1, row = 1, column = 2, padx=5, pady=5, sticky="we")
     tkbind(AnnEntry1, "<FocusIn>", function(K){
                            tclvalue(AnnTxt) <- ""
                            tkconfigure(AnnEntry1, foreground="red")
                     })
     tkbind(AnnEntry1, "<Key-Return>", function(K){
                            tkconfigure(AnnEntry1, foreground="black")
                            AnnotateText <<- tclvalue(AnnTxt)
                     })


     Anframe2 <- ttklabelframe(AnnGroup, text = "  Set Text Position ", borderwidth=2)
     tkgrid(Anframe2, row = 5, column = 1, padx = 5, pady = 5, sticky="we")
     TxtButt <- tkbutton(Anframe2, text=" TEXT POSITION ", command=function(){
                            #make a copy of the plot
                            trellis.focus("panel", 1, 1, clip.off=TRUE, highlight=FALSE)
                            RecPlot <- recordGraphics()

#                            D0 <- dev.cur()
#                            dev.new()
#                            bringToTop(which = D0)
#                            dev.set(which = D0)
#                            dev.copy(which = dev.next())
#                            dev.set(which = D0)

                            pos <- list(x=NULL, y=NULL)
                            WidgetState(Anframe1, "disabled")
                            WidgetState(Anframe2, "disabled")
                            WidgetState(Anframe3, "disabled")
                            WidgetState(BtnGroup, "disabled")
                            pos <- grid.locator(unit = "points")
                            X1 <- min(Xlim)  #Xlim, Ylim parameters passed to XPSLattAnnotate()
                            if (FName[[SpectIndx]]@Flags[1]) X1 <- max(Xlim)   #Binding Energy Set
                            RangeX <- abs(Xlim[2]-Xlim[1])
                            Y1 <- min(Ylim)
                            RangeY <- Ylim[2]-Ylim[1]
                            PosX <- max(convertX(unit(Xlim, "native"), "points", TRUE))
                            PosY <- max(convertY(unit(Ylim, "native"), "points", TRUE))
                            panel.identify(x=PosX, y=PosY, label=AnnotateText)
                            if (FName[[SpectIndx]]@Flags[1]){
                               TextPosition$x <<- X1-as.numeric(pos$x)*RangeX/PosX+RangeX/35  #Binding Energy Set
                            } else {
                               TextPosition$x <<- X1+as.numeric(pos$x)*RangeX/PosX-RangeX/35  #Kinetic energy scale
                            }
                            TextPosition$y <<- Y1+as.numeric(pos$y)*RangeY/PosY+RangeY/50
                            if (length(TextPosition)==0)  {
                               return()
                            }
                            TextSize <<- as.numeric(tclvalue(TSize))
                            if (is.na(TextSize)) {TextSize <<- 1}
                            replayPlot(RecPlot)
pippo
                            CtrlPlot()
                            tkdestroy(AnnotePosition)
                            txt <- paste("Text Position: X = ", round(TextPosition$x, 2), "  Y = ", round(TextPosition$y, 2), sep="")
                            AnnotePosition <- ttklabel(Anframe2, text=txt)
                            tkgrid(AnnotePosition, row = 1, column = 2, padx = 5, pady = 5, sticky="w")
                            WidgetState(Anframe1, "normal")
                            WidgetState(Anframe2, "normal")
                            WidgetState(Anframe3, "normal")
                            WidgetState(BtnGroup, "normal")

                     })
     tkgrid(TxtButt, row = 1, column = 1, padx = 5, pady = 5, sticky="w")
     AnnotePosition <- ttklabel(Anframe2, text="Text Position                ")
     tkgrid(AnnotePosition, row = 1, column = 2, padx = 5, pady = 5, sticky="w")

# ====>

     Anframe3 <- ttklabelframe(AnnGroup, text = " Text Size & Color ", borderwidth=2)
     tkgrid(Anframe3, row = 6, column = 1, padx = 5, pady =c(2, 5), sticky="we")
     tkgrid( ttklabel(Anframe3, text=" Size "),
             row = 1, column = 1, padx = 5, pady = 2, sticky="w")
     tkgrid( ttklabel(Anframe3, text=" Color "),
             row = 1, column = 2, padx = 5, pady = 2, sticky="w")

     TSize <- tclVar("1")
     AnnoteSize <- ttkcombobox(Anframe3, width = 15, textvariable = TSize, values = FontSize)
     tkbind(AnnoteSize, "<<ComboboxSelected>>", function(){
                            if (is.na(TextPosition)) {
                                tkmessageBox(message="Please set the Label Position first!", title="WARNING: position lacking", icon="warning")
                            } else {
                                replayPlot(AcceptedPlot)
                                TextSize <<- as.numeric(tclvalue(TSize))
                                trellis.focus("panel", 1, 1, clip.off=TRUE, highlight=FALSE)
                                CtrlPlot()
                            }
                     })
     tkgrid(AnnoteSize, row = 2, column = 1, padx = 5, pady =c(2, 5), sticky="w")

     TColor <- tclVar("black")
     AnnoteColor <- ttkcombobox(Anframe3, width = 15, textvariable = TColor, values = FontCol)
     tkbind(AnnoteColor, "<<ComboboxSelected>>", function(){
                            if (is.na(TextPosition)) {
                                tkmessageBox(message="Please set the Label Position first!", title="WARNING: position lacking", icon="warning")
                            } else {
#                                replayPlot(AcceptedPlot)
#                                TextColor <<- tclvalue(TColor)
#                                trellis.focus("panel", 1, 1, clip.off=TRUE, highlight=FALSE)
#                                CtrlPlot()

                              dev.set(which = dev.next()) #the backUp device
                              dev.copy(which = dev.prev()) #copy the original plot in the previous device
                              dev.set(which = D0)

                            }
                     })
     tkgrid(AnnoteColor, row = 2, column = 2, padx = 5, pady =c(2, 5), sticky="w")


     BtnGroup <- ttkframe(AnnWin, borderwidth=0, padding=c(0,0,0,0))
     tkgrid(BtnGroup, row = 7, column = 1, sticky="we")
     tkgrid.columnconfigure(BtnGroup, 1, weight = 1)  #needed to extend buttons with sticky="we"

     AddArwButt <- tkbutton(BtnGroup, text=" ADD ARROW ", command=function(){
                            TextColor <- tclvalue(TColor)
                            pos1 <- locator(n=1, type="p", pch=20, col=TextColor) #first mark the arrow start point
                            pos2 <- locator(n=1, type="n") #the arrow ending point
		                          arrows(pos1$x, pos1$y, pos2$x, pos2$y, length = 0.05, col = TextColor)
                     })
     tkgrid(AddArwButt, row = 1, column = 1, padx = 5, pady = 5, sticky="we")

     AcceptButt <- tkbutton(BtnGroup, text=" ACCEPT ", command=function(){
                            AcceptedPlot <<- recordPlot()  #accept the annotation in the graph NO UNDO now possible.
                     })
     tkgrid(AcceptButt, row = 2, column = 1, padx = 5, pady = 5, sticky="we")

     UndoButt <- tkbutton(BtnGroup, text=" UNDO ANNOTATE ", command=function(){
                            replayPlot(RecPlot)
                            trellis.unfocus()
                     })
     tkgrid(UndoButt, row = 3, column = 1, padx = 5, pady = 5, sticky="we")

     ExitButt <- tkbutton(BtnGroup, text="  EXIT  ", command=function(){
                            trellis.unfocus()
                            tkdestroy(AnnWin)
                     })
     tkgrid(ExitButt, row = 4, column = 1, padx = 5, pady = 5, sticky="we")

}

